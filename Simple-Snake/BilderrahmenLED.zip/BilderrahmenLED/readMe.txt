Required: 
FastLED Library must be under Windows: C:\Program Files (x86)\mBlock\Arduino\
libraries
